#ifndef PICKER_H
#define PICKER_H

#include "vector.h"

void pickFromXYPlane(Vector result, int x, int y);

#endif